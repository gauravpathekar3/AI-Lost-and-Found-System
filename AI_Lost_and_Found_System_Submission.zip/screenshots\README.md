# Capture the project screenshots

After starting the app with streamlit run app.py, capture these views with Snipping Tool or your system screenshot shortcut and save them in this folder:

1. 01_sample_match.png — the sample match shown when the app opens.
2. 02_photo_similarity.png — create one lost and one found report with similar item photos; capture the result showing the image similarity signal.
3. 03_pending_claim.png — submit the private clue for a matching pair and capture the pending staff-review message.

Use only the fictional sample reports or non-sensitive demo items. Do not capture private clues, real student information, IDs, faces, or contact details.
